package com.cg.exception;

public class EmpIdException extends Exception{

	public EmpIdException() {
		super();
	
	}

	public EmpIdException(String message) {
		super(message);
		
	}

	
}
